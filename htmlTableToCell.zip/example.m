function example


table.idTableBy.plaintextInFirstTD = 'Trondheim';
htmlTableToCell('example.html',table)

clear table;
table.idTableBy.plaintextInFirstTD = 'Norway';
htmlTableToCell('example.html',table)


